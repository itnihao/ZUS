#!/bin/bash
echored ()
{
echo -ne "\033[31m" $1 "\033[0m\n"
}
echogreen ()
{
echo -ne "\033[32m" $1 "\033[0m\n"
}

FlashSecLog="/var/log/flashsec.log"


echo "===" >>"${FlashSecLog}"
echo `date +"%Y-%m-%d %H:%M:%S"` start security_policy_server | tee -a "${FlashSecLog}"

which supervise | grep "supervise" || { echored "Error: pls install supervise,run: yum -y install daemontools" | tee -a "${FlashSecLog}" && exit 1; }

ExecDir="/data/web/flash_security"
cd ${ExecDir}

#check to avoid duplicate server start
SecurityServerName=${ExecDir}/bin/security_policy_server
ps aux | grep ${SecurityServerName} | grep -v "grep" && { echored "Error: ${SecurityServerName} is running." | tee -a "${FlashSecLog}" && exit 3; } 

chmod +x run_security/run bin/security_policy_server

#remove supervise directory
SecuritySuperviseFile="run_security/supervise"
if [ -d "$SecuritySuperviseFile" ]; then 
rm -rf $SecuritySuperviseFile ||  { echored "Error: can not delete $SecuritySuperviseFile dir." | tee -a "${FlashSecLog}" && exit 5; }
fi

#start server
sleep 1
nohup supervise ${ExecDir}/run_security &
sleep 5

#check whether server start successfully
ps aux | grep ${SecurityServerName} | grep -v "grep"
if [ $? -eq 0 ]
then
	echogreen "${SecurityServerName} start succeed." | tee -a "${FlashSecLog}"
else
	echored "${SecurityServerName} start fail." | tee -a "${FlashSecLog}"
fi

rm -f nohup.out 
chown -R nobody. ${ExecDir}
