前提：
1. 查看是否安装自动重启工具supervise (which supervise), 如果没有,按以下步骤安装supervise工具:
	wget http://cr.yp.to/daemontools/daemontools-0.76.tar.gz
	tar xvzf daemontools-0.76.tar.gz
	cd admin/daemontools-0.76
	sudo ./package/install
	没有用过这个工具的，可以google下 重点学习其中supervise的用法
2. ulimit -n  是65535
3. 日志存储在/data/web/logs/cxxlog/, 保证存在这个目录

c++服务器:
1. 介绍: /data/web/flash_security/目录下
	(1) bin/security_policy_server 安全服，保证flash可以连接
	
2. 启动: start_security.sh
   停服: stop_security.sh
   发布新版本操作步骤:(1)停服 (2)发布新版本 (3)启动.  
   一定要先停服，再发布！！！

3. 如果上述顺序错乱或误操作等各种未知异常情况发生时，造成这两个脚本不能正常启动和停止时，可以手动处理：
   (1) ps aux|grep "supervise /data/web/fight_and_chat/", 逐个kill掉supervise进程
   (2) ps aux|grep "/data/web/fight_and_chat/bin/security_policy_server" kill掉security_policy_server进程
   上述清理干净后, 执行sh start_security.sh
   
