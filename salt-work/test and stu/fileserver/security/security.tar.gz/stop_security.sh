#!/bin/sh
echored ()
{
echo -ne "\033[31m" $1 "\033[0m\n"
}
echogreen ()
{
echo -ne "\033[32m" $1 "\033[0m\n"
}

FlashSecLog="/var/log/flashsec.log"
echo "===" >> "${FlashSecLog}"
echo `date +"%Y-%m-%d %H:%M:%S"` | tee -a "${FlashSecLog}" 

which supervise | grep "supervise" || { echored "Error: pls install supervise,run: yum -y install daemontools" | tee -a "${FlashSecLog}" && exit 1; }


ExecDir="/data/web/flash_security"
cd ${ExecDir}

echo `date +"%Y-%m-%d %H:%M:%S"`

#1. stop supervise
ps aux|grep "supervise ${ExecDir}/run_security" | grep -v "grep" | awk '{print "kill security supervise pid " $2;system("kill -9 " $2 )}'

SecurityServerName=${ExecDir}/bin/security_policy_server
ps aux | grep ${SecurityServerName} | grep -v "grep" | awk '{print "kill security pid " $2;system("kill -9 " $2 )}'

ps aux | grep ${SecurityServerName} | grep -v "grep"
if [ $? -eq 0 ]
then
	echored "${SecurityServerName} stop fail." | tee -a "${FlashSecLog}" 
else
	echogreen "${SecurityServerName} stop succeed." | tee -a "${FlashSecLog}" 
fi

